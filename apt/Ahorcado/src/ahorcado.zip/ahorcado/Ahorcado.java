package ahorcado;

/**
 *
 * @author jesus
 */
public class Ahorcado {
    /*
            Regarding to MVC design
            Add the following stuff:
            - Ahorcado (this class) stuff
                - what kind of stuff?:
                    - 
     */
    public static void main(String[] args) { 
      View juego = new View();
    }   

}
